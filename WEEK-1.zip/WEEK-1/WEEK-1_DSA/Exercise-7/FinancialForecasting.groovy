public class FinancialForecasting {
    // Method to predict future value using recursion
    public double predictFutureValue(double presentValue, double growthRate, int years) {
        // Base case: If no more years left, return the present value
        if (years == 0) {
            return presentValue;
        }
        // Recursive case: Calculate the value for the next year
        return predictFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        FinancialForecasting forecasting = new FinancialForecasting();
        
        double presentValue = 1000.0; // Initial investment
        double growthRate = 0.05; // Annual growth rate (5%)
        int years = 10; // Number of years to forecast
        
        double futureValue = forecasting.predictFutureValue(presentValue, growthRate, years);
        
        System.out.println("Future value of the investment: " + futureValue);
    }
}
