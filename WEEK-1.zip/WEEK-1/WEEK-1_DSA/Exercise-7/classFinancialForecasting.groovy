public class FinancialForecasting {
    // Method to predict future value using iteration
    public double predictFutureValue(double presentValue, double growthRate, int years) {
        double futureValue = presentValue;
        for (int i = 0; i < years; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }

    public static void main(String[] args) {
        FinancialForecasting forecasting = new FinancialForecasting();
        
        double presentValue = 1000.0; // Initial investment
        double growthRate = 0.05; // Annual growth rate (5%)
        int years = 10; // Number of years to forecast
        
        double futureValue = forecasting.predictFutureValue(presentValue, growthRate, years);
        
        System.out.println("Future value of the investment: " + futureValue);
    }
}
