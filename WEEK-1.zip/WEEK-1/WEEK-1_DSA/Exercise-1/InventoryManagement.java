
import java.util.HashMap;
import java.util.Map;

public class InventoryManagement {
    private Map<String, Product> inventory;

    public InventoryManagement() {
        this.inventory = new HashMap<>();
    }

    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }

    public void updateProduct(String productId, int quantity, double price) {
        Product product = inventory.get(productId);
        if (product != null) {
            product.setQuantity(quantity);
            product.setPrice(price);
        }
    }

    public void deleteProduct(String productId) {
        inventory.remove(productId);
    }

    public Product getProduct(String productId) {
        return inventory.get(productId);
    }

    public void displayInventory() {
        for (Product product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        InventoryManagement inventory = new InventoryManagement();

        // Adding products
        Product product1 = new Product("P001", "Product 1", 100, 50.0);
        Product product2 = new Product("P002", "Product 2", 200, 30.0);
        inventory.addProduct(product1);
        inventory.addProduct(product2);

        // Displaying inventory
        inventory.displayInventory();

        // Updating a product
        inventory.updateProduct("P001", 150, 45.0);
        System.out.println("After updating P001:");
        inventory.displayInventory();

        // Deleting a product
        inventory.deleteProduct("P002");
        System.out.println("After deleting P002:");
        inventory.displayInventory();
    }
}
