import java.util.ArrayList;

public class LinearSearch {
    public static Product linearSearch(ArrayList<Product> products, String productName) {
        for (Product product : products) {
            if (product.getProductName().equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null;
    }
}
