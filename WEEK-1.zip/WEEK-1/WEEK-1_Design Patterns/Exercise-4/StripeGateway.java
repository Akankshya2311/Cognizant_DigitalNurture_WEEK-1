// File: PayPalGateway.java
public class PayPalGateway {
    public void makePayment(double amount) {
        System.out.println("Processing payment through PayPal: $" + amount);
    }
}

// File: StripeGateway.java
public class StripeGateway {
    public void executePayment(double amount) {
        System.out.println("Processing payment through Stripe: $" + amount);
    }
}
