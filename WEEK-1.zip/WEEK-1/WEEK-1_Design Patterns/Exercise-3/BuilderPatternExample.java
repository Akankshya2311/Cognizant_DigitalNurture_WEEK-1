public class BuilderPatternExample {
    public static void main(String[] args) {
        // Create a basic computer
        Computer basicComputer = new Computer.Builder()
                                    .setCPU("Intel i3")
                                    .setRAM("8GB")
                                    .setStorage("256GB SSD")
                                    .build();
        System.out.println(basicComputer);

        // Create a gaming computer
        Computer gamingComputer = new Computer.Builder()
                                    .setCPU("Intel i7")
                                    .setRAM("16GB")
                                    .setStorage("1TB SSD")
                                    .setGPU("NVIDIA RTX 3080")
                                    .setMotherboard("ASUS ROG")
                                    .setPowerSupply("750W")
                                    .build();
        System.out.println(gamingComputer);

        // Create a high-performance workstation
        Computer workstation = new Computer.Builder()
                                    .setCPU("AMD Ryzen 9")
                                    .setRAM("32GB")
                                    .setStorage("2TB NVMe SSD")
                                    .setGPU("NVIDIA Quadro RTX 6000")
                                    .setMotherboard("ASUS Pro WS")
                                    .setPowerSupply("1000W")
                                    .build();
        System.out.println(workstation);
    }
}
