public interface Notifier {
    void send(String message);
}
%%
public class EmailNotifier implements Notifier {
    @Override
    public void send(String message) {
        System.out.println("Sending Email: " + message);
    }
}
%%
public abstract class NotifierDecorator implements Notifier {
    protected Notifier wrapped;

    public NotifierDecorator(Notifier wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public void send(String message) {
        wrapped.send(message);
    }
}
%%
public class SMSNotifierDecorator extends NotifierDecorator {
    public SMSNotifierDecorator(Notifier wrapped) {
        super(wrapped);
    }

    @Override
    public void send(String message) {
        super.send(message);
        System.out.println("Sending SMS: " + message);
    }
}

public class SlackNotifierDecorator extends NotifierDecorator {
    public SlackNotifierDecorator(Notifier wrapped) {
        super(wrapped);
    }

    @Override
    public void send(String message) {
        super.send(message);
        System.out.println("Sending Slack message: " + message);
    }
}
%%
public class NotificationTest {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();

        Notifier smsAndEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackAndSmsAndEmailNotifier = new SlackNotifierDecorator(smsAndEmailNotifier);

        System.out.println("Sending using Email Notifier:");
        emailNotifier.send("Hello via Email!");

        System.out.println("\nSending using SMS and Email Notifier:");
        smsAndEmailNotifier.send("Hello via SMS and Email!");

        System.out.println("\nSending using Slack, SMS and Email Notifier:");
        slackAndSmsAndEmailNotifier.send("Hello via Slack, SMS and Email!");
    }
}
%%
public interface Notifier {
    void send(String message);
}
%%
public class EmailNotifier implements Notifier {
    @Override
    public void send(String message) {
        System.out.println("Sending Email: " + message);
    }
}
%%
public abstract class NotifierDecorator implements Notifier {
    protected Notifier wrapped;

    public NotifierDecorator(Notifier wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    public void send(String message) {
        wrapped.send(message);
    }
}
%%
public class SMSNotifierDecorator extends NotifierDecorator {
    public SMSNotifierDecorator(Notifier wrapped) {
        super(wrapped);
    }

    @Override
    public void send(String message) {
        super.send(message);
        System.out.println("Sending SMS: " + message);
    }
}
%%
public class SlackNotifierDecorator extends NotifierDecorator {
    public SlackNotifierDecorator(Notifier wrapped) {
        super(wrapped);
    }

    @Override
    public void send(String message) {
        super.send(message);
        System.out.println("Sending Slack message: " + message);
    }
}
%%
public class NotificationTest {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();

        Notifier smsAndEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackAndSmsAndEmailNotifier = new SlackNotifierDecorator(smsAndEmailNotifier);

        System.out.println("Sending using Email Notifier:");
        emailNotifier.send("Hello via Email!");

        System.out.println("\nSending using SMS and Email Notifier:");
        smsAndEmailNotifier.send("Hello via SMS and Email!");

        System.out.println("\nSending using Slack, SMS and Email Notifier:");
        slackAndSmsAndEmailNotifier.send("Hello via Slack, SMS and Email!");
    }
}
%%
